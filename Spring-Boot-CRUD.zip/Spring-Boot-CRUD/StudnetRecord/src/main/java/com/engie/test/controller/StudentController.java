package com.engie.test.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.engie.test.bean.Student;
import com.engie.test.service.impl.StudentService;

@Controller
@RequestMapping(path = "/crud", produces = "application/json")
public class StudentController {
	@Autowired
	StudentService studentService;

	@RequestMapping(value = "", method = RequestMethod.GET)
	public HttpEntity<List<Student>> getAllRecord() {

		List<Student> students = new ArrayList<Student>();
		students = studentService.getAllRecord();
		return new ResponseEntity<List<Student>>(students, HttpStatus.OK);
	}

	@RequestMapping(value = "", method = RequestMethod.POST, consumes = { "multipart/form-data" })
	public HttpEntity<Student> addRecord(@RequestParam(name = "firstName", required = true) String firstName,
			@RequestParam(name = "middleName", required = true) String middleName,
			@RequestParam(name = "lastName", required = true) String lastName,
			@RequestParam(name = "address", required = true) String address,
			@RequestParam(name = "email", required = true) String email,
			@RequestParam(name = "phoneNo", required = true) String phoneNo) {

		Student student = new Student();
		student.setFirstName(firstName);
		student.setMiddleName(middleName);
		student.setLastName(lastName);
		student.setAddress(address);
		student.setEmail(email);
		student.setPhoneNo(phoneNo);
		student = studentService.addRecord(student);
		return new ResponseEntity<Student>(student, HttpStatus.OK);
	}

	@RequestMapping(value = "/{studentId}", method = RequestMethod.PUT)
	public HttpEntity<Student> updateRecord(@RequestBody Student student,
			@PathVariable(value = "studentId") Integer studentId) {
		student = studentService.updateRecord(student, studentId);
		return new ResponseEntity<Student>(student, HttpStatus.OK);
	}
	

	@RequestMapping(value = "/{studentId}", method = RequestMethod.DELETE)
	public HttpEntity<Student> deleteRecord(@PathVariable(value = "studentId") Integer studentId) {
		Student student = studentService.deleteRecord(studentId);
		return new ResponseEntity<Student>(student, HttpStatus.OK);
	}

}
