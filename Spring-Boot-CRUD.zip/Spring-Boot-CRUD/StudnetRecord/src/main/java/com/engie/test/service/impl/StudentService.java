package com.engie.test.service.impl;

import java.awt.print.Pageable;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.id.PersistentIdentifierGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.engie.test.DAO.Impl.StudentRepository;
import com.engie.test.bean.Student;

@Service
public class StudentService {
	@Autowired
	StudentRepository studentRepository;

	public List<Student> getAllRecord() {

		List<Student> students = new ArrayList<Student>();
		students = (List<Student>) studentRepository.findAll();
		return students;

	}

	public Student addRecord(Student student) {
		student = studentRepository.save(student);
		return student;

	}

	public Student updateRecord(Student student, Integer sid) {
		Student student2 = studentRepository.findOne(sid);
		System.out.println(student2.getId());
		student2.setFirstName(student.getFirstName());
		student2.setMiddleName(student.getMiddleName());
		student2.setLastName(student.getLastName());
		student2.setAddress(student.getAddress());
		student2.setEmail(student.getEmail());
		student2.setPhoneNo(student.getPhoneNo());

		student = studentRepository.save(student2);
		return student;

	}

	public Student deleteRecord(Integer sid) {

		Student student = studentRepository.findOne(sid);
		studentRepository.delete(student);
		return student;

	}

}
