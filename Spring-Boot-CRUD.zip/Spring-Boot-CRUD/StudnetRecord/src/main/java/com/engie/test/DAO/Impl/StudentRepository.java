package com.engie.test.DAO.Impl;

import org.springframework.data.repository.CrudRepository;

import com.engie.test.bean.Student;

public interface StudentRepository extends CrudRepository<Student,Integer>{

}
